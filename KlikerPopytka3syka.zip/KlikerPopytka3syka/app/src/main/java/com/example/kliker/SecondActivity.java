package com.example.kliker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;


public class SecondActivity extends AppCompatActivity {
    private Button clickButton;
    private Button upgrade_click;
    private TextView DPSTextView;
    private Button DPS_UP;
    private TextView clickCountTextView;
    private TextView ClickLevelTextView;
    private TextView upgrade_text_view;
    private double clickCount = 0;
    private int ClickLevel = 1;
    private double upgradecost = 10;
    private double DPS = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        ClickLevelTextView = findViewById(R.id.click_level_text_view);
        upgrade_click = findViewById(R.id.Upgrade_click);
        upgrade_text_view = findViewById(R.id.upgrade_cost);
        clickButton = findViewById(R.id.click_button);
        clickCountTextView = findViewById(R.id.click_count_text_view);
        DPS_UP = findViewById(R.id.DPS);
        DPSTextView = findViewById(R.id.DPS_text_view);

    }

    @Override
    public void onResume() {
        super.onResume();
        upgrade_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (clickCount < upgradecost) {
                    System.out.println("Привет, мир!");
                } else {
                    ClickLevel += 1;
                    clickCount -= upgradecost;
                    ClickLevelTextView.setText("Сила Клика: " + ClickLevel);
                    clickCountTextView.setText("Количество Кликов: " + clickCount);
                    upgradecost *= 1.4;
                    DecimalFormat df = new DecimalFormat("#.##");
                    String formattedValue = df.format(upgradecost);
                    upgrade_text_view.setText(formattedValue);
                }
            }
        });

        DPS_UP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DPS = DPS + 0.6;
                DecimalFormat df = new DecimalFormat("#.##");
                String DPSFORMATED = df.format(DPS);
                DPSTextView.setText("DPS: " + DPSFORMATED);
            }
        });

        clickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount += ClickLevel;
                DecimalFormat df = new DecimalFormat("#.##");
                String DPSFORMATED = df.format(clickCount);
                clickCountTextView.setText("Количество Кликов: " + DPSFORMATED);
            }
        });

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                clickCount += DPS;  // Увеличиваем clickCount на основе значения DPS
                DecimalFormat df = new DecimalFormat("#.##");
                String formatedClickCount = df.format((clickCount));
                clickCountTextView.setText("Количество Кликов: " + formatedClickCount);  // Обновляем отображение clickCount
                handler.postDelayed(this, 1000);  // Повторяем через 1 секунду
            }
        }, 1000);  // Запускаем сразу и повторяем через 1 секунду

    }
}
